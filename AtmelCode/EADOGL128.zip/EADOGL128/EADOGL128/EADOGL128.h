/*
Reihe = Spalte
Page  = acht geb�ndelte Pixel -> Page 0(1) enth�lt Reihen 0-7(8-15)
*/

#ifndef EADOGL128_H
#define EADOGL128_H

#define F_CPU 8000000 //>4*f_ExtQuarz
#define F_CRYSTAL 32768
#define PRESCALER_TIMER2 128
#include <util/delay.h>
#include <avr/sbit.h>
#include <avr/io.h>
#include <math.h>
#include <avr/pgmspace.h>
#include <avr/interrupt.h>
#include <stdbool.h>
#include <avr/sleep.h>
#include "symbols"

#define LCD_CS SBIT(PORTD, 6)
#define LCD_RST SBIT(PORTD, 7)
#define LCD_A0 SBIT(PORTB, 0)
#define LCD_D SBIT(PORTD, 5)
#define LCD_CLK SBIT(PORTB, 1)//PB7



/*#define weckerWidth 24
#define alphaSmall 8

 uint8_t wecker [][(int)weckerWidth] PROGMEM ={   {0x0, 0x0, 0x38, 0x9c, 0xce, 0xee, 0x67, 0x37, 0x37, 0x12, 0x18, 0x18, 0xd8, 0x18, 0x18, 0x12, 0x37, 0x37, 0x67, 0xee, 0xce, 0x9c, 0x38, 0x0},
{0x0, 0xf8, 0xfe, 0xf, 0x3, 0x0, 0x0, 0x0, 0x0, 0x80, 0xc0, 0x60, 0x3f, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x3, 0xf, 0xfe, 0xf8},
{0x0, 0x1, 0x3, 0xf, 0x1c, 0x38, 0x70, 0x62, 0xc3, 0xc1, 0xc0, 0xc0, 0xc0, 0xc0, 0xc0, 0xc0, 0xc0, 0x60, 0x70, 0x38, 0x1c, 0xf, 0x3, 0x1} };*/

//Initialisiert das Display
void lcdInit(); 

//Steuerwort senden
void sendCmd(uint8_t);

//Daten schreiben
void sendData(uint8_t);

//Reihe setzen c = {0..127}
//Eine Reihe enth�lt 8 Pages
//0x0:  leastSignificant bits werden gesendet
//0x10: mostSignificant bits werden gesendet
void setColumn(uint8_t);

//Page setzen p={0..7};
//Eine Page enth�lt 8px
//0xB0: Page = 0;
void setPage(uint8_t);

//Alle Pixel ausschalten
void clearLCD();

//Pixel an x, y setzen
//x = {0..127}, y = {0..63}
//setzMaske ist nur "1" an der Stelle, wo der Pixel gesetzt werden soll
void setPixel(uint8_t, uint8_t);

//Pixelmaske auf LCD schreiben
void updateLCD();

//Symbol in Pixelmaske schreiben
int printSymbol(int height, int width, uint8_t[height/8*width], int, int);

//Konvertiert einen String in eine Reihenfolge von letter
void convertString(char [], int []);

//Schreibt einen String von letters an die �bergeben Position (Startwerte f�r linke obere Ecke des Strings)
//void printText(const letter [], int, int);

void printLetter(int, int, int, int, int);

int getMonthWidth();

int getDayWidth();

void printDate();

void printDay(int);

void printMonth(int);

void printSmallNumber(int, int, int);

void printBigNumber(int, int, int);

void resetPixel(uint8_t x, uint8_t y);

void printTime();

int printHour();

void printMinute();

void updateTimeXPos();

void incrementDate();

void updateTime();

void resetAlarmLogo();

void printAlarmLogo();

bool checkForTimeUpdate();

void goodNight();

void configureTimerAndInterrupts();

int printTimeDot(int, int); 
#endif